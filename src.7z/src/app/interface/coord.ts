export interface Coord {
    lon: number;
    lat: number;
}
