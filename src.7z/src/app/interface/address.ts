export interface Address {
    name: string;
    state: string;
    postcode: string;
    country: string;
    country_code: string;
    county: string;
    suburb: string;
}
