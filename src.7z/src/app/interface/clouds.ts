export interface Clouds {
    all: number;
}
