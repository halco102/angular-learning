export interface Wind {
    speed: number;
    deg: number;
    gust: number;
}
