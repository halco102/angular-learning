export interface Rain {
    '1h': number;
}
