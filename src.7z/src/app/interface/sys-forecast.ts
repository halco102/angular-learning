export interface SysForecast {
    pod: string;
}
