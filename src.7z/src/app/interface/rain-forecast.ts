export interface RainForecast {
    '3h': number;
}
