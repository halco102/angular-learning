export const environment = {
    apiKey : '2b437dbbf07f05212c02b852de987142',
    baseUrl : 'https://api.openweathermap.org'
};
